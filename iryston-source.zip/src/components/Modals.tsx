import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { Check, Trash2, X } from 'lucide-react'
import { auth } from '@lork/sdk'
import {
  OWNER_EMAIL,
  approvePendingNews,
  deletePendingNews,
  fetchPendingNews,
  formatNewsDate,
  isOwnerPassword,
  publishNews,
  submitNews,
  type PendingNewsItem,
} from '@/lib/news'

const fieldClass =
  'w-full rounded-lg border border-[#D6D3D1] bg-white px-3 py-2.5 text-[15px] text-[#1C1917] outline-none transition-colors placeholder:text-[#78716C] hover:border-[#A8A29E] focus:border-[#DC2626] focus:shadow-[0_0_0_3px_#FEE2E2]'

const labelClass = 'mb-1.5 block text-sm font-semibold text-[#57534E]'

const primaryButtonClass =
  'inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#B91C1C] px-4 py-2.5 text-[15px] font-semibold text-white transition-colors hover:bg-[#991B1B] disabled:cursor-not-allowed disabled:opacity-60'

const errorClass = 'mt-3 rounded-lg bg-[#FEF2F2] px-3 py-2 text-sm text-[#B91C1C]'

const successClass =
  'mt-3 rounded-lg border border-[#A7F3D0] bg-[#ECFDF5] px-3 py-2 text-sm text-[#047857]'

type ModalProps = {
  title: string
  wide?: boolean
  onClose: () => void
  children: ReactNode
}

function Modal({ title, wide = false, onClose, children }: ModalProps) {
  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        onClose()
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = previousOverflow
    }
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-[#0C0A09]/60 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`relative flex max-h-[90vh] w-full flex-col overflow-hidden rounded-2xl border border-[#E7E5E4] bg-white shadow-2xl ${
          wide ? 'max-w-3xl' : 'max-w-md'
        }`}
      >
        <div className="flex items-center justify-between gap-4 border-b border-[#E7E5E4] px-6 py-4">
          <h2 className="text-lg font-bold text-[#1C1917]">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Ахӕсс"
            className="rounded-md p-1.5 text-[#78716C] transition-colors hover:bg-[#FAFAF9] hover:text-[#7F1D1D]"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
        <div className="overflow-y-auto px-6 py-5">{children}</div>
      </div>
    </div>
  )
}

type AuthModalProps = {
  mode: 'login' | 'register'
  onModeChange: (mode: 'login' | 'register') => void
  onClose: () => void
  onAuthenticated: () => void | Promise<void>
}

export function AuthModal({ mode, onModeChange, onClose, onAuthenticated }: AuthModalProps) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [pending, setPending] = useState(false)

  const isRegister = mode === 'register'

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError(null)
    setNotice(null)

    const normalizedEmail = email.trim().toLowerCase()

    if (isRegister && normalizedEmail !== OWNER_EMAIL) {
      setError('Дӕхи бафысын нал ис гӕнӕн')
      return
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      setError('Введите корректный email')
      return
    }

    if (password.length < 6) {
      setError('Пароль должен содержать не менее 6 символов')
      return
    }

    if (isRegister && !(await isOwnerPassword(password))) {
      setError('Пароль не подходит для регистрации владельца')
      return
    }

    setPending(true)

    try {
      if (isRegister) {
        const response = await auth.signUpWithPassword({ email: normalizedEmail, password })
        if (response.needs_email_confirmation) {
          setNotice('Подтвердите email по ссылке из письма, затем войдите.')
          return
        }
      } else {
        await auth.signInWithPassword({ email: normalizedEmail, password })
      }

      await onAuthenticated()
    } catch {
      setError(
        isRegister
          ? 'Не удалось зарегистрироваться. Попробуйте позже.'
          : 'Неверный email или пароль',
      )
    } finally {
      setPending(false)
    }
  }

  return (
    <Modal title={isRegister ? 'Дӕхи бафысс' : 'Бахиз'} onClose={onClose}>
      <form onSubmit={handleSubmit} noValidate>
        <div>
          <label className={labelClass} htmlFor="auth-email">
            Email
          </label>
          <input
            id="auth-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className={fieldClass}
            placeholder="name@example.com"
          />
        </div>

        <div className="mt-4">
          <label className={labelClass} htmlFor="auth-password">
            Дӕгъӕл
          </label>
          <input
            id="auth-password"
            type="password"
            autoComplete={isRegister ? 'new-password' : 'current-password'}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className={fieldClass}
            placeholder="••••••"
          />
        </div>

        {error && <p className={errorClass}>{error}</p>}
        {notice && <p className={successClass}>{notice}</p>}

        <button type="submit" disabled={pending} className={`${primaryButtonClass} mt-5`}>
          {pending ? '…' : isRegister ? 'Дӕхи бафысс' : 'Бахиз'}
        </button>

        <button
          type="button"
          onClick={() => {
            setError(null)
            setNotice(null)
            onModeChange(isRegister ? 'login' : 'register')
          }}
          className="mt-4 w-full text-center text-sm text-[#57534E] transition-colors hover:text-[#7F1D1D]"
        >
          {isRegister ? 'Дӕхи баффыстай? Бахиз' : 'Дӕхи нырма баффыстай? Дӕхи баффыс'}
        </button>
      </form>
    </Modal>
  )
}

type SubmitModalProps = {
  isOwner: boolean
  authorEmail: string | null
  authorId: string | null
  onClose: () => void
  onSubmitted: () => void
}

export function SubmitModal({
  isOwner,
  authorEmail,
  authorId,
  onClose,
  onSubmitted,
}: SubmitModalProps) {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, setPending] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError(null)

    const trimmedTitle = title.trim()
    const trimmedBody = body.trim()

    if (!trimmedTitle) {
      setError('Введите заголовок новости')
      return
    }

    if (!trimmedBody) {
      setError('Введите текст новости')
      return
    }

    setPending(true)

    try {
      if (isOwner) {
        await publishNews({
          title: trimmedTitle,
          body: trimmedBody,
          authorEmail,
          authorId,
        })
      } else {
        await submitNews({
          title: trimmedTitle,
          body: trimmedBody,
          authorEmail,
        })
      }

      onSubmitted()
    } catch {
      setError('Не удалось отправить новость. Попробуйте ещё раз.')
    } finally {
      setPending(false)
    }
  }

  return (
    <Modal title="Хабӕрттӕ бахӕсс" onClose={onClose}>
      <form onSubmit={handleSubmit} noValidate>
        <div>
          <div className="mb-1.5 flex items-baseline justify-between gap-3">
            <label className={`${labelClass} mb-0`} htmlFor="news-title">
              Сӕр
            </label>
            <span className="text-xs text-[#78716C]">{title.length}/200</span>
          </div>
          <input
            id="news-title"
            type="text"
            maxLength={200}
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            className={fieldClass}
          />
        </div>

        <div className="mt-4">
          <div className="mb-1.5 flex items-baseline justify-between gap-3">
            <label className={`${labelClass} mb-0`} htmlFor="news-body">
              Ныхас
            </label>
            <span className="text-xs text-[#78716C]">{body.length}/5000</span>
          </div>
          <textarea
            id="news-body"
            rows={7}
            maxLength={5000}
            value={body}
            onChange={(event) => setBody(event.target.value)}
            className={`${fieldClass} resize-y leading-relaxed`}
          />
        </div>

        {error && <p className={errorClass}>{error}</p>}

        <button type="submit" disabled={pending} className={`${primaryButtonClass} mt-5`}>
          {pending ? '…' : 'Арвит'}
        </button>
      </form>
    </Modal>
  )
}

type ModerationModalProps = {
  onClose: () => void
  onChanged: () => void
}

export function ModerationModal({ onClose, onChanged }: ModerationModalProps) {
  const [items, setItems] = useState<PendingNewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const pending = await fetchPendingNews()
      setItems(pending)
      setError(null)
    } catch {
      setError('Не удалось загрузить новости на проверку.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function handleApprove(item: PendingNewsItem) {
    setBusyId(item.id)
    setError(null)
    try {
      await approvePendingNews(item)
      await load()
      onChanged()
    } catch {
      setError('Не удалось выложить новость. Попробуйте ещё раз.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete(item: PendingNewsItem) {
    if (!window.confirm('Удалить новость?')) {
      return
    }

    setBusyId(item.id)
    setError(null)
    try {
      await deletePendingNews(item.id)
      await load()
      onChanged()
    } catch {
      setError('Не удалось удалить новость. Попробуйте ещё раз.')
    } finally {
      setBusyId(null)
    }
  }

  return (
    <Modal title="Фидар кӕны" wide onClose={onClose}>
      {error && <p className={`${errorClass} mt-0 mb-4`}>{error}</p>}

      {loading ? (
        <div className="space-y-4" aria-hidden="true">
          <div className="h-24 animate-pulse rounded-xl bg-[#FAFAF9]" />
          <div className="h-24 animate-pulse rounded-xl bg-[#FAFAF9]" />
        </div>
      ) : items.length === 0 ? (
        <p className="py-6 text-center text-[15px] text-[#78716C]">
          Хабӕрттӕ фидар нӕма цӕуынц
        </p>
      ) : (
        <ul className="space-y-4">
          {items.map((item) => (
            <li
              key={item.id}
              className="rounded-xl border border-[#E7E5E4] bg-white p-5 shadow-sm"
            >
              <p className="text-sm font-semibold text-[#B91C1C]">
                {formatNewsDate(item.created_at)}
              </p>
              <h3 className="mt-2 text-lg font-bold leading-snug text-[#1C1917]">
                {item.title}
              </h3>
              <p className="mt-2 whitespace-pre-line text-[15px] leading-relaxed text-[#44403C]">
                {item.body}
              </p>
              <div className="mt-4 flex flex-wrap items-center justify-end gap-2">
                <button
                  type="button"
                  disabled={busyId === item.id}
                  onClick={() => void handleDelete(item)}
                  className="inline-flex items-center gap-2 rounded-lg border border-[#D6D3D1] bg-white px-3 py-2 text-sm font-medium text-[#1C1917] transition-colors hover:border-[#A8A29E] hover:text-[#7F1D1D] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" />
                  Айсын
                </button>
                <button
                  type="button"
                  disabled={busyId === item.id}
                  onClick={() => void handleApprove(item)}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#B91C1C] px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#991B1B] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <Check className="h-4 w-4" aria-hidden="true" />
                  Сӕвӕрын
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  )
}
